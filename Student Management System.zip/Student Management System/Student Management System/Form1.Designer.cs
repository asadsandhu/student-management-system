﻿
namespace Student_Management_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add_Teacher = new System.Windows.Forms.Button();
            this.Add_Student = new System.Windows.Forms.Button();
            this.Display_Teacher = new System.Windows.Forms.Button();
            this.Display_Student = new System.Windows.Forms.Button();
            this.Edit_Teacher = new System.Windows.Forms.Button();
            this.Edit_Student = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Add_Teacher
            // 
            this.Add_Teacher.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Add_Teacher.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Teacher.ForeColor = System.Drawing.SystemColors.Info;
            this.Add_Teacher.Location = new System.Drawing.Point(525, 266);
            this.Add_Teacher.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Add_Teacher.Name = "Add_Teacher";
            this.Add_Teacher.Size = new System.Drawing.Size(330, 77);
            this.Add_Teacher.TabIndex = 0;
            this.Add_Teacher.Text = "Add new Teacher";
            this.Add_Teacher.UseVisualStyleBackColor = false;
            this.Add_Teacher.Click += new System.EventHandler(this.Add_Teacher_Click);
            // 
            // Add_Student
            // 
            this.Add_Student.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Add_Student.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Add_Student.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Student.ForeColor = System.Drawing.SystemColors.Info;
            this.Add_Student.Location = new System.Drawing.Point(525, 180);
            this.Add_Student.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Add_Student.Name = "Add_Student";
            this.Add_Student.Size = new System.Drawing.Size(330, 77);
            this.Add_Student.TabIndex = 1;
            this.Add_Student.Text = "Add new Student";
            this.Add_Student.UseVisualStyleBackColor = false;
            this.Add_Student.Click += new System.EventHandler(this.button2_Click);
            // 
            // Display_Teacher
            // 
            this.Display_Teacher.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Display_Teacher.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Display_Teacher.ForeColor = System.Drawing.SystemColors.Info;
            this.Display_Teacher.Location = new System.Drawing.Point(525, 611);
            this.Display_Teacher.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Display_Teacher.Name = "Display_Teacher";
            this.Display_Teacher.Size = new System.Drawing.Size(330, 77);
            this.Display_Teacher.TabIndex = 2;
            this.Display_Teacher.Text = "Show Teacher Details";
            this.Display_Teacher.UseVisualStyleBackColor = false;
            // 
            // Display_Student
            // 
            this.Display_Student.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Display_Student.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Display_Student.ForeColor = System.Drawing.SystemColors.Info;
            this.Display_Student.Location = new System.Drawing.Point(525, 525);
            this.Display_Student.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Display_Student.Name = "Display_Student";
            this.Display_Student.Size = new System.Drawing.Size(330, 77);
            this.Display_Student.TabIndex = 3;
            this.Display_Student.Text = "Show Student Details";
            this.Display_Student.UseVisualStyleBackColor = false;
            this.Display_Student.Click += new System.EventHandler(this.Display_Student_Click);
            // 
            // Edit_Teacher
            // 
            this.Edit_Teacher.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Edit_Teacher.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edit_Teacher.ForeColor = System.Drawing.SystemColors.Info;
            this.Edit_Teacher.Location = new System.Drawing.Point(525, 438);
            this.Edit_Teacher.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Edit_Teacher.Name = "Edit_Teacher";
            this.Edit_Teacher.Size = new System.Drawing.Size(330, 77);
            this.Edit_Teacher.TabIndex = 4;
            this.Edit_Teacher.Text = "Edit Teacher Details";
            this.Edit_Teacher.UseVisualStyleBackColor = false;
            // 
            // Edit_Student
            // 
            this.Edit_Student.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Edit_Student.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edit_Student.ForeColor = System.Drawing.SystemColors.Info;
            this.Edit_Student.Location = new System.Drawing.Point(525, 352);
            this.Edit_Student.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Edit_Student.Name = "Edit_Student";
            this.Edit_Student.Size = new System.Drawing.Size(330, 77);
            this.Edit_Student.TabIndex = 5;
            this.Edit_Student.Text = "Edit Student Details";
            this.Edit_Student.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(0, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1444, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "*********************************************************************************" +
    "********************************************************************************" +
    "******************";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Algerian", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Title.Location = new System.Drawing.Point(0, 35);
            this.Title.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(1347, 89);
            this.Title.TabIndex = 7;
            this.Title.Text = "|STUDENT MANAGEMENT SYSTEM|";
            this.Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Title.Click += new System.EventHandler(this.label2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(0, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1444, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "*********************************************************************************" +
    "********************************************************************************" +
    "******************";
            this.label2.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Info;
            this.button1.Location = new System.Drawing.Point(525, 697);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(330, 77);
            this.button1.TabIndex = 2;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(1356, 825);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Edit_Student);
            this.Controls.Add(this.Edit_Teacher);
            this.Controls.Add(this.Display_Student);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Display_Teacher);
            this.Controls.Add(this.Add_Student);
            this.Controls.Add(this.Add_Teacher);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Add_Teacher;
        private System.Windows.Forms.Button Add_Student;
        private System.Windows.Forms.Button Display_Teacher;
        private System.Windows.Forms.Button Display_Student;
        private System.Windows.Forms.Button Edit_Teacher;
        private System.Windows.Forms.Button Edit_Student;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}

