﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management_System
{
    public partial class Student : Form
    {
        int ID = 0;
        string path = Environment.CurrentDirectory + "/" + "Student.txt";

        public Student()
        {
            InitializeComponent();
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();

            if (!File.Exists(path))
                File.CreateText(path);

            using (StreamWriter sw = new StreamWriter(path,true))
            {
                ID++;
                sw.WriteLine(ID);
                sw.WriteLine(F_Name.Text);
                sw.WriteLine(L_Name.Text);
                sw.WriteLine(Username.Text);
                sw.WriteLine(Email.Text);
                sw.WriteLine(Contact_No.Text);
                sw.WriteLine(Blood_Group.Text);
                sw.WriteLine(Address.Text);
                if(Male_Button.Checked==true)
                    sw.WriteLine("Male");
                else
                    sw.WriteLine("Female");
                sw.WriteLine(Reg_Date.Text);
                if (Fee_Status.Checked == true)
                    sw.WriteLine("Paid");
                else
                    sw.WriteLine("Not Paid");
                sw.Close();
            }
        }
    }
}
