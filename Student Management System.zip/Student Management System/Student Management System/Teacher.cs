﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management_System
{
    public partial class Teacher : Form
    {
        int ID = 0;
        string path = Environment.CurrentDirectory + "/" + "Teacher.txt";

        public Teacher()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();

            if (!File.Exists(path))
                File.CreateText(path);

            using (StreamWriter sw = new StreamWriter(path,true))
            {
                ID++;
                sw.WriteLine(ID);
                sw.WriteLine(F_Name.Text);
                sw.WriteLine(L_Name.Text);
                sw.WriteLine(Username.Text);
                sw.WriteLine(Email.Text);
                sw.WriteLine(Contact_No.Text);
                sw.WriteLine(Blood_Group.Text);
                sw.WriteLine(Address.Text);
                if (Male_Button.Checked == true)
                    sw.WriteLine("Male");
                else
                    sw.WriteLine("Female");
                sw.WriteLine(Reg_Date.Text);
                sw.Close();
            }
        }
    }
}
