﻿
namespace Student_Management_System
{
    partial class Teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Reg_Date = new System.Windows.Forms.DateTimePicker();
            this.Female_Button = new System.Windows.Forms.RadioButton();
            this.Male_Button = new System.Windows.Forms.RadioButton();
            this.Address = new System.Windows.Forms.TextBox();
            this.Blood_Group = new System.Windows.Forms.TextBox();
            this.Contact_No = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.TextBox();
            this.L_Name = new System.Windows.Forms.TextBox();
            this.F_Name = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(3, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(893, 16);
            this.label12.TabIndex = 51;
            this.label12.Text = "*********************************************************************************" +
    "********************************************************************************" +
    "****************";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(3, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(893, 16);
            this.label11.TabIndex = 50;
            this.label11.Text = "*********************************************************************************" +
    "********************************************************************************" +
    "****************";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Algerian", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label10.Location = new System.Drawing.Point(176, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(568, 59);
            this.label10.TabIndex = 49;
            this.label10.Text = "|Add New Teacher|";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.ForeColor = System.Drawing.SystemColors.Info;
            this.button1.Location = new System.Drawing.Point(369, 413);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 49);
            this.button1.TabIndex = 46;
            this.button1.Text = "Submit and Add Student";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Info;
            this.label9.Location = new System.Drawing.Point(12, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 17);
            this.label9.TabIndex = 38;
            this.label9.Text = "Address :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Info;
            this.label8.Location = new System.Drawing.Point(12, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "Contact No :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Info;
            this.label7.Location = new System.Drawing.Point(12, 232);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "Blood Group :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Info;
            this.label6.Location = new System.Drawing.Point(12, 285);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 17);
            this.label6.TabIndex = 35;
            this.label6.Text = "Gender :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Info;
            this.label5.Location = new System.Drawing.Point(12, 310);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 17);
            this.label5.TabIndex = 34;
            this.label5.Text = "Registration Date :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Info;
            this.label4.Location = new System.Drawing.Point(12, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 33;
            this.label4.Text = "Email :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Info;
            this.label3.Location = new System.Drawing.Point(12, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 17);
            this.label3.TabIndex = 32;
            this.label3.Text = "Username :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(12, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 31;
            this.label2.Text = "Last Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.Location = new System.Drawing.Point(12, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 30;
            this.label1.Text = "First Name :";
            // 
            // Reg_Date
            // 
            this.Reg_Date.Location = new System.Drawing.Point(145, 310);
            this.Reg_Date.Name = "Reg_Date";
            this.Reg_Date.Size = new System.Drawing.Size(200, 20);
            this.Reg_Date.TabIndex = 65;
            // 
            // Female_Button
            // 
            this.Female_Button.AutoSize = true;
            this.Female_Button.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Female_Button.ForeColor = System.Drawing.SystemColors.Info;
            this.Female_Button.Location = new System.Drawing.Point(209, 283);
            this.Female_Button.Name = "Female_Button";
            this.Female_Button.Size = new System.Drawing.Size(71, 21);
            this.Female_Button.TabIndex = 63;
            this.Female_Button.TabStop = true;
            this.Female_Button.Text = "Female";
            this.Female_Button.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Female_Button.UseVisualStyleBackColor = true;
            // 
            // Male_Button
            // 
            this.Male_Button.AutoSize = true;
            this.Male_Button.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Male_Button.ForeColor = System.Drawing.SystemColors.Info;
            this.Male_Button.Location = new System.Drawing.Point(145, 283);
            this.Male_Button.Name = "Male_Button";
            this.Male_Button.Size = new System.Drawing.Size(58, 21);
            this.Male_Button.TabIndex = 62;
            this.Male_Button.TabStop = true;
            this.Male_Button.Text = "Male";
            this.Male_Button.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Male_Button.UseVisualStyleBackColor = true;
            // 
            // Address
            // 
            this.Address.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Address.ForeColor = System.Drawing.SystemColors.Info;
            this.Address.Location = new System.Drawing.Point(145, 257);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(95, 20);
            this.Address.TabIndex = 61;
            // 
            // Blood_Group
            // 
            this.Blood_Group.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Blood_Group.ForeColor = System.Drawing.SystemColors.Info;
            this.Blood_Group.Location = new System.Drawing.Point(145, 231);
            this.Blood_Group.Name = "Blood_Group";
            this.Blood_Group.Size = new System.Drawing.Size(95, 20);
            this.Blood_Group.TabIndex = 60;
            // 
            // Contact_No
            // 
            this.Contact_No.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Contact_No.ForeColor = System.Drawing.SystemColors.Info;
            this.Contact_No.Location = new System.Drawing.Point(145, 205);
            this.Contact_No.Name = "Contact_No";
            this.Contact_No.Size = new System.Drawing.Size(95, 20);
            this.Contact_No.TabIndex = 59;
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Email.ForeColor = System.Drawing.SystemColors.Info;
            this.Email.Location = new System.Drawing.Point(145, 179);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(95, 20);
            this.Email.TabIndex = 58;
            // 
            // Username
            // 
            this.Username.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Username.ForeColor = System.Drawing.SystemColors.Info;
            this.Username.Location = new System.Drawing.Point(145, 153);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(95, 20);
            this.Username.TabIndex = 57;
            // 
            // L_Name
            // 
            this.L_Name.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.L_Name.ForeColor = System.Drawing.SystemColors.Info;
            this.L_Name.Location = new System.Drawing.Point(145, 127);
            this.L_Name.Name = "L_Name";
            this.L_Name.Size = new System.Drawing.Size(95, 20);
            this.L_Name.TabIndex = 56;
            // 
            // F_Name
            // 
            this.F_Name.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.F_Name.ForeColor = System.Drawing.SystemColors.Info;
            this.F_Name.Location = new System.Drawing.Point(145, 101);
            this.F_Name.Name = "F_Name";
            this.F_Name.Size = new System.Drawing.Size(95, 20);
            this.F_Name.TabIndex = 55;
            // 
            // Teacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(904, 536);
            this.Controls.Add(this.Reg_Date);
            this.Controls.Add(this.Female_Button);
            this.Controls.Add(this.Male_Button);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.Blood_Group);
            this.Controls.Add(this.Contact_No);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.L_Name);
            this.Controls.Add(this.F_Name);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Teacher";
            this.Text = "Teacher";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker Reg_Date;
        private System.Windows.Forms.RadioButton Female_Button;
        private System.Windows.Forms.RadioButton Male_Button;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox Blood_Group;
        private System.Windows.Forms.TextBox Contact_No;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Username;
        private System.Windows.Forms.TextBox L_Name;
        private System.Windows.Forms.TextBox F_Name;
    }
}